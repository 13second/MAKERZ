#!/usr/bin/env python3
"""
SPIRIT-IP_LDC — Parametric Aston-Spirit-Style 3D Studio LDC Enclosure (build123d)
- Crystal-Clear 8001 Resin Outer Body (Ø 54.0 mm x 114.0 mm, 3 recessed switch slots + PCB rails + 5/8" thread boss)
- 316L Stainless Steel Helical Wave-Form Upper Grille (Ø 54.0 mm x 62.0 mm, JLC3DP SLM Metal)
- Triple-Port Bottom Cap (XLR-3M + RJ45 PoE + USB-C cutouts)
- Shock-Isolated 34mm Capsule Saddle + Reference 34mm Gold Capsule + Main 4L PCB + Headamp 2L PCB
Exports STL + STEP + GLB + watertight verification via trimesh + JLC3DP ZIP!
"""
import json
import math
import zipfile
from pathlib import Path
import trimesh
from build123d import (
    Axis, BuildPart, Cylinder, Box, Location, Locations, Mode,
    Compound, export_stl, export_step, fillet, chamfer
)

ROOT = Path(__file__).resolve().parent.parent
DIM = json.loads((ROOT / "dimensions.json").read_text(encoding="utf-8"))
OUT_3D = ROOT / "exports" / "3d"
OUT_3D.mkdir(parents=True, exist_ok=True)

ENC = DIM["enclosure"]
R_OUT = ENC["outer_diameter_mm"] / 2.0      # 27.0 mm
WALL = ENC["wall_thickness_mm"]             # 3.0 mm
R_IN = R_OUT - WALL                         # 24.0 mm
H_BODY = ENC["body_height_mm"]              # 114.0 mm
H_GRILLE = ENC["grille_height_mm"]          # 62.0 mm
H_CAP = ENC["bottom_cap_height_mm"]         # 12.0 mm


def make_body_clear():
    """Crystal-Clear 8001 Resin Body with 3 Aston-Spirit recessed switch slots & internal PCB rails."""
    with BuildPart() as p:
        # Main cylinder Z=[H_CAP .. H_BODY]
        with Locations((0, 0, H_CAP + (H_BODY - H_CAP) / 2.0)):
            Cylinder(radius=R_OUT, height=H_BODY - H_CAP)
            Cylinder(radius=R_IN, height=H_BODY - H_CAP + 2.0, mode=Mode.SUBTRACT)
        # Top shoulder step to seat the metal grille
        with Locations((0, 0, H_BODY + 2.5)):
            Cylinder(radius=R_IN + 1.4, height=5.0)
            Cylinder(radius=R_IN, height=6.0, mode=Mode.SUBTRACT)
        # 2 internal vertical PCB guide rails (for 38 mm wide Main PCB)
        for sx in (-20.8, 20.8):
            with Locations((sx, 0, H_CAP + (H_BODY - H_CAP) / 2.0)):
                Box(3.6, 5.0, H_BODY - H_CAP - 4.0)
                Box(2.2, 2.0, H_BODY - H_CAP - 2.0, mode=Mode.SUBTRACT)
        # 3 recessed front switch slots (+Y face)
        for sw in ENC["switch_slots"]:
            with Locations((0, R_OUT - 1.0, sw["z_mm"])):
                Box(sw["w_mm"], 8.0, sw["h_mm"], mode=Mode.SUBTRACT)
    return p.part


def make_grille_316l():
    """Aston-Spirit inspired open wave-form upper cage for JLC3DP 316L Stainless Steel SLM."""
    with BuildPart() as p:
        # Bottom collar ring
        with Locations((0, 0, H_BODY + 3.0)):
            Cylinder(radius=R_OUT, height=6.0)
            Cylinder(radius=R_IN + 1.5, height=7.0, mode=Mode.SUBTRACT)
        # Top crown ring
        z_top = H_BODY + H_GRILLE - 4.0
        with Locations((0, 0, z_top)):
            Cylinder(radius=R_OUT - 1.5, height=6.0)
            Cylinder(radius=R_IN - 2.5, height=7.0, mode=Mode.SUBTRACT)
        # Top dome cross-bars (4 bars)
        for ang in (0, 45, 90, 135):
            with Locations(Location((0, 0, z_top + 1.5), (0, 0, ang))):
                Box(R_OUT * 1.85, 2.4, 2.4)
        # 12 vertical structural ribs around perimeter (clean printable wave-form cage)
        n_ribs = 12
        for k in range(n_ribs):
            ang_rad = 2 * math.pi * k / n_ribs
            rx = (R_OUT - 1.4) * math.cos(ang_rad)
            ry = (R_OUT - 1.4) * math.sin(ang_rad)
            with Locations(Location((rx, ry, H_BODY + H_GRILLE / 2.0), (0, 0, math.degrees(ang_rad)))):
                Box(2.4, 2.2, H_GRILLE - 4.0)
        # 3 horizontal wave rings
        for z_ring in (H_BODY + 18.0, H_BODY + 34.0, H_BODY + 50.0):
            with Locations((0, 0, z_ring)):
                Cylinder(radius=R_OUT - 0.3, height=2.6)
                Cylinder(radius=R_OUT - 2.6, height=3.2, mode=Mode.SUBTRACT)
    return p.part


def make_bottom_cap():
    """Dual-Port Bottom Cap (Pure Digital): RJ45 PoE + USB-C cutouts + 5/8-27 brass thread boss."""
    ports = ENC["bottom_ports"]
    with BuildPart() as p:
        with Locations((0, 0, H_CAP / 2.0)):
            Cylinder(radius=R_OUT, height=H_CAP)
        # Inner lip that slides into the clear body
        with Locations((0, 0, H_CAP + 2.5)):
            Cylinder(radius=R_IN - 0.15, height=5.0)
            Cylinder(radius=R_IN - 3.0, height=6.0, mode=Mode.SUBTRACT)
        # Hollow interior pocket above bottom plate (3.5 mm base plate thickness)
        with Locations((0, 0, 3.5 + (H_CAP - 3.5) / 2.0)):
            Cylinder(radius=R_IN - 3.0, height=H_CAP - 3.0, mode=Mode.SUBTRACT)
        # Cutout 1: 5/8"-27 Brass Mic Stand Insert Bore (Ø 15.875 mm)
        tx, ty = ports["thread_insert_5_8_offset_xy_mm"]
        with Locations((tx, ty, H_CAP / 2.0)):
            Cylinder(radius=ports["thread_insert_5_8_diameter_mm"] / 2.0, height=H_CAP + 8.0, mode=Mode.SUBTRACT)
        # Cutout 2: RJ45 PoE (16.4 x 13.8 mm)
        rx, ry = ports["rj45_offset_xy_mm"]
        rw, rh = ports["rj45_cutout_wh_mm"]
        with Locations((rx, ry, H_CAP / 2.0)):
            Box(rw, rh, H_CAP + 8.0, mode=Mode.SUBTRACT)
        # Cutout 3: USB-C UAC2 (9.4 x 3.6 mm)
        ux, uy = ports["usbc_offset_xy_mm"]
        uw, uh = ports["usbc_cutout_wh_mm"]
        with Locations((ux, uy, H_CAP / 2.0)):
            Box(uw, uh, H_CAP + 8.0, mode=Mode.SUBTRACT)
    return p.part


def make_capsule_saddle():
    """Shock-isolated 34mm LDC capsule saddle sitting atop the Headamp deck."""
    with BuildPart() as p:
        # Base deck at Z = H_BODY + 2 mm
        with Locations((0, 0, H_BODY + 2.0)):
            Cylinder(radius=R_IN - 0.4, height=4.0)
            # Center wire pass-through hole
            Cylinder(radius=4.0, height=6.0, mode=Mode.SUBTRACT)
        # Saddle cradle rising to Z = 132 mm
        with Locations((0, 0, H_BODY + 10.0)):
            Box(18.0, 12.0, 14.0)
            with Locations((0, 0, 14.0)):
                Cylinder(radius=17.3, height=16.0, rotation=(90, 0, 0), mode=Mode.SUBTRACT)
    return p.part


def make_ref_parts():
    """Reference visual parts for MAKERZ Studio 3D viewer (not 3D printed)."""
    # 34mm gold capsule
    with BuildPart() as cap:
        with Locations((0, 0, DIM["capsule"]["saddle_z_mm"] + 12.0)):
            Cylinder(radius=17.0, height=10.0, rotation=(90, 0, 0))
    # Main 4L PCB (38x94x1.6 mm)
    with BuildPart() as mpcb:
        with Locations((0, 0, H_CAP + 49.0)):
            Box(38.0, 1.6, 94.0)
    # Headamp 2L PCB (Ø 36.0 x 1.6 mm)
    with BuildPart() as hpcb:
        with Locations((0, 0, H_BODY - 3.0)):
            Cylinder(radius=18.0, height=1.6)
    return cap.part, mpcb.part, hpcb.part


def save_part(part, stem, check_watertight=True):
    stl_p = OUT_3D / f"{stem}.stl"
    step_p = OUT_3D / f"{stem}.step"
    glb_p = OUT_3D / f"{stem}.glb"
    export_stl(part, str(stl_p))
    export_step(part, str(step_p))
    mesh = trimesh.load(str(stl_p), force="mesh")
    mesh.export(str(glb_p))
    if check_watertight:
        assert mesh.is_watertight, f"ERROR: {stl_p.name} is NOT watertight!"
    print(f"  [OK] {stem}: watertight={mesh.is_watertight}, vol={mesh.volume/1000:.2f} cm3")
    return stl_p, mesh


def main():
    print("=== Building SPIRIT-IP_LDC 3D Enclosure ===")
    body = make_body_clear()
    grille = make_grille_316l()
    cap = make_bottom_cap()
    saddle = make_capsule_saddle()
    cap_ref, mpcb_ref, hpcb_ref = make_ref_parts()

    stls_print = []
    for part, stem, wt in [
        (body, "SPIRIT-IP_body_clear_8001", True),
        (grille, "SPIRIT-IP_grille_316L_metal", True),
        (cap, "SPIRIT-IP_bottom_cap_triple_port", True),
        (saddle, "SPIRIT-IP_capsule_saddle", True),
        (cap_ref, "SPIRIT-IP_capsule_34mm", False),
        (mpcb_ref, "SPIRIT-IP_main_pcb", False),
        (hpcb_ref, "SPIRIT-IP_headamp_pcb", False),
    ]:
        stl_p, _ = save_part(part, stem, check_watertight=wt)
        if wt:
            stls_print.append(stl_p)

    # Full assembly STEP + GLB
    asm = Compound(children=[body, grille, cap, saddle, cap_ref, mpcb_ref, hpcb_ref])
    export_step(asm, str(OUT_3D / "SPIRIT-IP_assembly.step"))
    export_stl(asm, str(OUT_3D / "SPIRIT-IP_assembly.stl"))
    trimesh.load(str(OUT_3D / "SPIRIT-IP_assembly.stl"), force="mesh").export(str(OUT_3D / "SPIRIT-IP_assembly.glb"))

    # Package JLC3DP ZIP (4 printable watertight STLs)
    zpath = OUT_3D / "SPIRIT-IP_JLC3DP_3DPrint_STL.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in stls_print:
            zf.write(p, p.name)
    print(f"Exported JLC3DP ZIP -> {zpath}")


if __name__ == "__main__":
    main()
